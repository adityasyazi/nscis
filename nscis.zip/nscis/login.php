<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style/style.css" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
</head>
<body>
    <div class="row">
        <div class="column center">
        
        </div>

        <div class="column side">

        <form action="/action_page.php" method="post">
        <div class="imgcontainer">
        <img src="image/nsc.jpg" alt="Avatar" class="avatar" style="width:150px" >
        </div>

        <div class="container">
        <label for="uname"><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="uname" require>

        <label for="psw"><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="psw" require>
        <button class="button button1" type="submit">Login</button>
        
        </div>
        </form>
        </div>
    </div>
</body>
</html>