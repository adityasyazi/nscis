<?php
    $mysqli = new mysqli('localhost','root','1234','nscis');
    if($mysqli->connect_errno)
        {
            echo 'gagal';
            exit();
        }
?>