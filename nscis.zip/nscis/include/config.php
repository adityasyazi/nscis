<?php
    $mysqli = new mysqli('localhost','adit','1234','nscis');
    if($mysqli->connect_errno)
        {
            echo 'gagal';
            exit();
        }
?>