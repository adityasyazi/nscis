<?php
    include_once('include/header-admin.php');
?>

<div class="row">
    <div class="column side">
        <div class="card">
        <img src="../pro.jpg" alt="Avatar" style="width:100%" class="imgcard">
        <div class="containercard">
            <h4><b>Asep</b><br>Officer ID:0000000</h4>
            <p>Interior Designer</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Flugiat ipsa laborum esse eos,.....</p>
        </div>
        </div>
    </div>

    <div class="column right">
        <div class="container">
            <h2>Title</h2>
            <h4>Title decription, Dec 29, 2017</h4>
            <img src="../moment.jpg" alt="Avatar" style="width:500px; height:300px;" class="imghome">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus harum, perferendis exercitationem est odit labore sunt rem suscipit ut facere eveniet illo quos dolorem inventore incidunt, modi ipsum ex dolore!</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus harum, perferendis exercitationem est odit labore sunt rem suscipit ut facere eveniet illo quos dolorem inventore incidunt, modi ipsum ex dolore!</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus harum, perferendis exercitationem est odit labore sunt rem suscipit ut facere eveniet illo quos dolorem inventore incidunt, modi ipsum ex dolore!</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus harum, perferendis exercitationem est odit labore sunt rem suscipit ut facere eveniet illo quos dolorem inventore incidunt, modi ipsum ex dolore!</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus harum, perferendis exercitationem est odit labore sunt rem suscipit ut facere eveniet illo quos dolorem inventore incidunt, modi ipsum ex dolore!</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus harum, perferendis exercitationem est odit labore sunt rem suscipit ut facere eveniet illo quos dolorem inventore incidunt, modi ipsum ex dolore!</p>
        </div>
    </div>
</div>