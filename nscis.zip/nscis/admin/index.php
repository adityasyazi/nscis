<?php
    include_once('../include/header-admin.php');
?>

<div class ="row">
    <div class ="column side">
        <div class ="card">
        <img src="../pro.jpg" alt="Avatar" style="width:100%" class="imgcard">
            <div class="containercard">
                <h4><b>Asep</b><br>Officer ID : 000000</h4>
                </p>Interior Design</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, aut quaerat? Sunt doloremque ipsa esse, nostrum perspiciatis incidunt unde expedita distinctio, nulla repudiandae, aspernatur repellendus facere ut vero. Saepe, incidunt?</p>
            </div>
        </div>
    </div>
    <div class="column right">
        <div class="container">
        <h2>Tittle</h2>
        <h4>Title Description, Dec 29, 2017</h4>
        <img src="../moment.jpg" alt="Avatar" style="width:500px; height:300px" class="imghome">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus tempore incidunt, reprehenderit quibusdam dolorum qui obcaecati nam corrupti, earum, praesentium voluptatem ut exercitationem quod! Fugiat commodi tempore nesciunt deleniti. Corrupti!</p>
        <a href="read" class="btn btn-large">Read More..</a>
        </div><br>
        <div class="container">
        <h2>Tittle</h2>
        <h4>Title Description, Dec 29, 2017</h4>
        <img src="../moment.jpg" alt="Avatar" style="width:500px; height:300px" class="imghome">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus tempore incidunt, reprehenderit quibusdam dolorum qui obcaecati nam corrupti, earum, praesentium voluptatem ut exercitationem quod! Fugiat commodi tempore nesciunt deleniti. Corrupti!</p>
        <a href="read" class="btn btn-large">Read More..</a>
        </div><br>
        <div class="container">
        <h2>Tittle</h2>
        <h4>Title Description, Dec 29, 2017</h4>
        <img src="../moment.jpg" alt="Avatar" style="width:500px; height:300px" class="imghome">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus tempore incidunt, reprehenderit quibusdam dolorum qui obcaecati nam corrupti, earum, praesentium voluptatem ut exercitationem quod! Fugiat commodi tempore nesciunt deleniti. Corrupti!</p>
        <a href="read" class="btn btn-large">Read More..</a>
        </div><br>
        <div class="container">
        <h2>Tittle</h2>
        <h4>Title Description, Dec 29, 2017</h4>
        <img src="../moment.jpg" alt="Avatar" style="width:500px; height:300px" class="imghome">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus tempore incidunt, reprehenderit quibusdam dolorum qui obcaecati nam corrupti, earum, praesentium voluptatem ut exercitationem quod! Fugiat commodi tempore nesciunt deleniti. Corrupti!</p>
        <a href="read" class="btn btn-large">Read More..</a>
        </div><br>
        <div class="container">
        <h2>Tittle</h2>
        <h4>Title Description, Dec 29, 2017</h4>
        <img src="../moment.jpg" alt="Avatar" style="width:500px; height:300px" class="imghome">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus tempore incidunt, reprehenderit quibusdam dolorum qui obcaecati nam corrupti, earum, praesentium voluptatem ut exercitationem quod! Fugiat commodi tempore nesciunt deleniti. Corrupti!</p>
        <a href="read" class="btn btn-large">Read More..</a>
        </div><br>
        <div class="pagination">
        <a href="#">&laquo;</a>
        <a href="#">1</a>
        <a class="active" href="#">2</a>
        <a href="#">3</a>
        <a href="#">4</a>
        <a href="#">5</a>
        <a href="#">6</a>
        <a href="#">&raquo;</a>
        </div>
    </div>
</div>

<?php
    include_once('../include/footer.php');
?>