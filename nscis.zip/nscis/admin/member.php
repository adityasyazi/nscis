<?php
error_reporting(E_ALL | E_WARNING | E_NOTICE);
ini_set('display_errors', TRUE);
include_once('../include/config.php');
$title = 'member';

$no = 1;
    // memnampilkan position berdasarkan nama position bukan id_positio
    $sql = ("SELECT member.id_member, member.first_name, member.last_name, member.full_name, member.address, member.no_phone, 
              member.foto, member.bio, member.dob, member.email, member.gender, member.religion, member.password, position.position_name, member.status, member.create_date, member.is_admin
              FROM member 
              JOIN position ON position.id_position = member.position_id");

    $sql_count = "SELECT COUNT(*) FROM member";
    if (isset($sql_where)) {
        $sql .= $sql_where;
        $sql_count .= $sql_where;
    }
    $result_count = mysqli_query($mysqli, $sql_count);
    $count = 0;
    if ($result_count) {
        $r_data = mysqli_fetch_row($result_count);
        $count = $r_data[0];
    }
    $per_page = 5;
    $num_page = ceil($count / $per_page);
    $limit = $per_page;
    if (isset($_GET['page'])) {
        $page = $_GET['page'];
        $offset = ($page - 1) * $per_page;
    } else {
        $offset = 0;
        $page = 1;
    }
    $sql .= " LIMIT {$offset}, {$limit}";    

    $result = mysqli_query($mysqli, $sql);
  
    include_once('../include/header-admin.php');
?>

<div class="row">

            <div class="column full">
                    <h2>Member Data</h2>
                    <?php
     echo '<a href="add-member.php" class="btn btn-large"><i class="fa fa-plus" aria-hidden="true"></i> Members</a>'; 
    ?>
                    <p>Data of all officer Ngoding Study Club</p>
                    
                    <div class="row">
                        <div class="col-25">
                        <input id="myInput" type="search" name="search" placeholder="Search...." >
                        </div>
                      </div><br>
                    <div style="overflow-x:auto;">
                            <table>
                            <thead>
                                    <tr>
                                      <th>No.</th>
                                      <th>Photo</th>
                                      <th>Officer ID</th>
                                      <th>Full Name</th>
                                      <th>Position</th>
                                      <th>Email</th>
                                      <th>No. Phone</th>
                                      <th>DoB</th>
                                      <th>Gender</th>
                                      <th>Religion</th>
                                      <th>Address</th>
                                      <th>Status</th>
                                      <th>Action</th>
                            </thead>    
                                    <?php while($row = mysqli_fetch_array($result)): ?>
                              <tbody id="myTable">
                                    <tr>
                                      <td><?php echo $no; ?></td>
                                      <td><img src="<?php echo "../image/".$row['foto']; ?>" width ="90px"; height="150px";></td>
                                      <td><?php echo $row['id_member'];?></td>
                                      <td><?php echo $row['full_name'];?></td>
                                      <td><?php echo $row['position_name'];?></td>
                                      <td><?php echo $row['email'];?></td>
                                      <td><?php echo $row['no_phone'];?></td>
                                      <td><?php echo $row['dob'];?></td>
                                      <td><?php echo $row['gender'];?></td>
                                      <td><?php echo $row['religion'];?></td>
                                      <td><?php echo $row['address'];?></td>
                                      <?php
                                        if ($row['status'] == 'Active') {
                                           echo"<td style ='color:green'><b>".$row['status']."</b></td>";
                                        }else{
                                            echo"<td style ='color:red'><b>".$row['status']."</b></td>"; 
                                        } 
                                      ?>
                                      <td>
                                        <a class="btn btn-default" href="edit-member.php?id=<?php echo $row['id_member'];?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
                                        <a class="btn btn-alert" onclick="return confirm('Are you sure you want to delete this data?');" href="delete-member.php?id_member=<?php echo $row['id_member'];?>"><i class="fa fa-trash" aria-hidden="true"></i> Delete</a>
                                        <a class="btn btn-default" href="view-member.php?id=<?php echo $row['id_member'];?>"><i class="fa fa-eye" aria-hidden="true"></i> View</a>
                                      </td>
                                    </tr>
                                    </tbody>
                                    <?php $no++; ?>
                                    <?php endwhile; ?>
                                  </table>
            
                    </div>
                    <div class="pagination">

                    
                        <a href="?page=<?php if ($page > 1){
                            $pagep = $page-1;
                        }else{
                            $pagep= $page;
                        } 
                        echo $pagep; ?>">&laquo;</a>
                        <?php for ($i=1; $i <= $num_page; $i++) { 
                            $link = "?page={$i}";
                            if (!empty($q)) $link .= "&q={$q}";
                                $class = ($page == $i ? 'active' : '');
                                echo "<a class=\"{$class}\" href=\"{$link}\">{$i}</a>";
                            } ?>
                      <!--  <li>
                            <a href="">...</a>
                            <a href="">9</a>
                            <a href="">10</a>
                            <a href="">11</a>
                        </li> -->
                     <a href="?page=<?php if ($page < $num_page){
                        $pagen = $page+1;
                    }else{
                        $pagen= $page;
                    }
                    echo $pagen; ?>">&raquo;</a>
                   



                        <!-- <a href="#">&laquo;</a>
                        <a href="#">1</a>
                        <a class="active" href="#">2</a>
                        <a href="#">3</a>
                        <a href="#">4</a>
                        <a href="#">5</a>
                        <a href="#">6</a>
                        <a href="#">&raquo;</a> -->
                    </div>
            </div>
        </div>

<?php
    include_once('../include/footer.php');
?>