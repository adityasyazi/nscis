<?php
include_once('../include/header-admin.php');
?>

<div class="row">
    <div class="column side"></div>
    <div class="column middle">
    <h2>Announce Form</h2>
    <p>please fill in your announce in the folowing form</p>
    <div class="container">
        <form action="/action_page.php">
        
        <!-- material name -->
        <div class="row">
            <div class="col-25">
                <label for="title">Title</label>
            </div>
            <div class="col-75">
                <input type="text" id="title" name="title" placeholder="Your title..">
            </div>
        </div>

        <!-- Description -->
        <div class="row">
            <div class="col-25">
                <label for="desc">Description</label>
            </div>
            <div class="col-75">
            <textarea name="desc" id="desc" placeholder="Write something.."
            style="height:200px"></textarea>
            </div>
        </div>

        <!-- photo file -->
        <div class="row">
            <div class="col-25">
                <label for="photo">Photo</label>
            </div>
            <div class="col-75">
                <input type="file" name="photo" placeholder="Your Photo..">
            </div>
        </div>
        <div class="row">
            <input type="submit" value="Submit">
        </div>
        </form>
    </div>
    </div>
    <div class="column side">
    </div>
</div>

<?php
    include_once('../include/footer.php')
?>