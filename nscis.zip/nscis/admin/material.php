<?php
    include_once('../include/header-admin.php');
?>

<div class="row">
    <div class="column full">
        <h2>Materials Data</h2>
        <?php
            echo '<a href="add-material.php" class="btn btn-large"> <i class="fa fa-plus" aria-hidden="true"></i>Materials</a>';
        ?>
        <p>Data of All NSC Learning Materials</p>
        <div class="row">
            <div class="col-25">
            <input type="search" name="search" placeholder="Search...">
            </div>
        </div><br>
        <div style="overflow-x:auto;">
        <table>
            <tr>
                <th>No.</th>
                <th>Material Name</th>
                <th>Description</th>
                <th>Date Post</th>
                <th>Material</th>
                <th>The Officers</th>
                <th>Action</th>
            </tr>
            <tr>
                <td>1</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>Material</td>
                <td>Sas</td>
                <td>&nbsp;</td>
                <td>
                    <a class="btn btn-default" href=""><i class="fa fa-download" aria-hidden="true"></i>Download</a>
                    <a class="btn btn-default" href=""><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</a>
                    <a class="btn btn-default" href=""><i class="fa fa-trash" aria-hidden="true"></i>Edit</a>
                </td>
            </tr>
            <tr>
                <td>2</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>Material</td>
                <td>Sas</td>
                <td>&nbsp;</td>
                <td>
                    <a class="btn btn-default" href=""><i class="fa fa-download" aria-hidden="true"></i>Download</a>
                    <a class="btn btn-default" href=""><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</a>
                    <a class="btn btn-default" href=""><i class="fa fa-trash" aria-hidden="true"></i>Edit</a>
                </td>
            </tr>
            <tr>
                <td>3</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>Material</td>
                <td>Sas</td>
                <td>&nbsp;</td>
                <td>
                    <a class="btn btn-default" href=""><i class="fa fa-download" aria-hidden="true"></i>Download</a>
                    <a class="btn btn-default" href=""><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</a>
                    <a class="btn btn-default" href=""><i class="fa fa-trash" aria-hidden="true"></i>Edit</a>
                </td>
            </tr>
            <tr>
                <td>4</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>Material</td>
                <td>Sas</td>
                <td>&nbsp;</td>
                <td>
                    <a class="btn btn-default" href=""><i class="fa fa-download" aria-hidden="true"></i>Download</a>
                    <a class="btn btn-default" href=""><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</a>
                    <a class="btn btn-default" href=""><i class="fa fa-trash" aria-hidden="true"></i>Edit</a>
                </td>
            </tr>
            <tr>
                <td>5</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>Material</td>
                <td>Sas</td>
                <td>&nbsp;</td>
                <td>
                    <a class="btn btn-default" href=""><i class="fa fa-download" aria-hidden="true"></i>Download</a>
                    <a class="btn btn-default" href=""><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</a>
                    <a class="btn btn-default" href=""><i class="fa fa-trash" aria-hidden="true"></i>Edit</a>
                </td>
            </tr>
            <tr>
                <td>6</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>Material</td>
                <td>Sas</td>
                <td>&nbsp;</td>
                <td>
                    <a class="btn btn-default" href=""><i class="fa fa-download" aria-hidden="true"></i>Download</a>
                    <a class="btn btn-default" href=""><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</a>
                    <a class="btn btn-default" href=""><i class="fa fa-trash" aria-hidden="true"></i>Edit</a>
                </td>
            </tr>
        </table>
        </div>
        <div class="pagination">
        <a href="#">&laquo;</a>
        <a href="#">1</a>
        <a class="active" href="#">2</a>
        <a href="#">3</a>
        <a href="#">4</a>
        <a href="#">5</a>
        <a href="#">6</a>
        <a href="#">&raquo;</a>
        </div>
    </div>
</div>

<?php
    include_once('../include/footer.php');
?>