<?php
    include_once('../include/header-admin.php');
?>

<div class="row">
    <div class="column side">
    </div>
    <div class="column middle">
    <h2>Material Form</h2>
    <p>please fill in your materials in the following form</P>
        <div class="container">
        <form action="/action_page.php">

        <!-- Material Name -->
            <div class="row">
                <div class="col-25">
                    <label for="mname">Material Name</label>
                </div>
                <div class="col-75">
                    <input type="text" id="mname" name="material_name" placeholder="Material Name...">
                </div>
            </div>

        <!-- Description -->
            <div class="row">
                <div class="col-25">
                    <label for="desc">Description</label>
                </div>
                <div class="col-75">
                    <textarea id="mname" name="desc" placeholder="Write Something..." style="height:200px"></textarea>
                </div>
            </div>

        <!-- Material File -->
            <div class="row">
                <div class="col-25">
                    <label for="Materi">Material</label>
                </div>
                <div class="col-75">
                    <input type="file" name="Materi" placeholder="Your Material...">
                </div>
            </div>

            <div class="row">
                <input type="submit" value="Submit">
            </div>
        </form>
        </div>
    </div>
    <div class="column side">
    </div>
</div>

<?php
    include_once('../include/footer.php');
?>