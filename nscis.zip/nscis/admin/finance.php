
<?php
     error_reporting(E_ALL | E_WARNING | E_NOTICE);
     ini_set('display_errors', TRUE);
     include_once('../include/config.php');
     $title = 'add finance';
     $no = 1;

 
     $sql = 'SELECT * FROM petty_cash';
     $result = mysqli_query($mysqli, $sql);
      
    include_once('../include/header-admin.php');
    
?>
<div class="row">
    <div class="column full">
        <h2>Finance Data</h2>
    
        <?php
        echo '<a href="add-credit.php" class="btn btn-large"><i class="fa fa-plus" aria-hidden="true"
        ></i> Credit</a>';

        echo '<a href="add-debit.php" class="btn btn-success"><i class="fa fa-plus" aria-hidden="true"
        ></i> Debit</a>';
        ?>

        <p>Data of all finance NSC</p>
        <div class="row">
            <div class="col-25">
                <input type="search" name="search" placeholder="search.....">
            </div>
        </div><br>

        <div class="row">
            <div class="col-20">
                <input type="text" id="tdDate" name="datefirst" placeholder="Date....">
            </div>

            <div class="col-10">
                S/D 
            </div>
            <div class="col-20">
                <input type="text" id="tdDate1" name="datefirst1" placeholder="Date....">
            </div>

            <div class="col-5">
                <a href="print" class="btn btn-print"><i class="fa fa-print" aria-hidden="true">
                </i> Print</a>
           </div>
        </div><br>  

            <div style="overflow-x:auto;">
                <table>
                    <tr>
                        <th>No.</th>
                        <th>The Officer</th>
                        <th>Date Input</th>
                        <th>Description</th>
                        <th>Credit</th>
                        <th>Debit</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                        <?php while($row = mysqli_fetch_array($result)): ?>
                    <tr>
                                        
                        <td><?php echo $no; ?></td>
                        <td><?php echo $row['id_petty'];?></td>
                        <td><?php echo $row['date'];?></td>
                        <td><?php echo $row['description'];?></td>
                        <td><?php echo 'Rp.'. number_format($row['kredit'],2,",",".");?></td>
                        <td><?php echo 'Rp.'. number_format($row['debit'],2,",",".");?></td>
                        <td><?php echo 'Rp.'. number_format($row['saldo'],2,",",".");?></td>
                        <td>
                            <a class="btn btn-alert" onclick="return confirm('Are you sure you want to delete this data?');" href="delete-finance.php?id_petty=<?php echo $row['id_petty'];?>"><i class="fa fa-trash" aria-hidden="true"></i> Delete</a>
                        </td>
                    </tr>
                    <?php $no++; ?>
                    <?php endwhile; ?>

                </table>
            </div>

            <div class="pagination">
                <a href="#">&laquo;</a>
                <a href="#">1</a>
                <a class="active" href="#">2</a>
                <a href="#">3</a>
                <a href="#">4</a>            
                <a href="#">5</a>
                <a href="#">6</a> 
                <a href="#">&raquo;</a> 
            </div>
     </div>
</div>

<?php
    include_once('../include/footer.php');
?>