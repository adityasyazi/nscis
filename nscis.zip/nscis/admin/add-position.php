<?php

// notifikasi error kodingan
error_reporting(E_ALL | E_WARNING | E_NOTICE);
ini_set('display_errors', TRUE);
// memanggil koneksi database
include_once('../include/config.php');

    $title = 'add position';
    
    // membuat variabel position dan jobdesc yang ok dan error dengan value nya kosong atau belum terisi
    $position = $jobdesc ='';
    $positionerr = $jobdescerr ='';
    // membuat fungsi dengan isset untuk mengecek data kemudian di kirimkan data dengan metode post yang berarti semua data sekaligus di submit
    if (isset($_POST['submit'])) {

        //position
        // jika positionnya kosong, trim fungsinya utk menghapuskan spasi atau ruang kosong, 
        // lalu di kirim lah data dengan metode post ke dalam variabel position yang belum ada 
        // valuenya maka akan keluar notifikasi untuk mengisi form
        // dan jika terisi maka akan di inputkan dengan metode post ke dalam variabel position
        if (empty(trim($_POST['position']))) {
          $positionerr = "please fill in the position";
        }else {
          $position = trim($_POST['position']);
        }
     
        // job description
        if (empty(trim($_POST['jobdesc']))) {
          $jobdescerr = "please fill in the jobdesc";
        }else {
          $jobdesc = trim($_POST['jobdesc']);
        }

        //insert to table
        // jika tidak kosong variabel position dan tidak kosong juga variabel jobdesc nya, 
        // maka dibuatan variabel sql dengan perintah masukan data ke dalam tabel position di kolom position_name
        // dan kolom job_desk dengan nilai dari variabel position dan variabel jobdesc
        // kemudian membuat variabel result atau hasilnya untuk menampilkan data inputan sql yang dikoneksikan 
        if (!empty($position) && !empty($jobdesc)) {
          $sql = "INSERT INTO position (position_name, job_desk) VALUES ('{$position}', '{$jobdesc}')";
          $result = mysqli_query($mysqli, $sql);
          
          // jika tidak tertampil hasilnya maka data tidak tersimpan
          if (!$result) {
            die(mysqli_error($mysqli));
          }
          
          // setelah di inputkan maka akan di menampilkan data posisi
          header('Location: position.php');
        }

    }
    // memanggil halaman headir-admin.php
    include_once('../include/header-admin.php');


?>


<!-- membuat tampilan data yang sudah diinputkan ke database -->
<div class="row">
      <div class="column side">

      </div>

      <div class="column middle">
          <h2>Position Form</h2>
          <p>please fill in your position in the following form</p>
          
          <div class="container">
            <form action="add-position.php" method="post" enctype="multipart/form-data">
            
              <!-- position -->
              <div class="row">
                <div class="col-25">
                  <label for="position">Position</label>
                </div>
                <div class="col-75">
                  <input type="text" id="position" value="<?php echo $position; ?>" name="position" placeholder="Your position..">
                  <span class="error"><?php echo $positionerr; ?></span>
                </div>
              </div>

              <!-- jobdesc -->
              <div class="row">
                <div class="col-25">
                  <label for="jobdesc">Job Description</label>
                </div>
                <div class="col-75">
                  <textarea id="address" name="jobdesc" value="<?php echo $jobdesc; ?> placeholder="Write something.." style="height:200px">
                </textarea>
                <span class="error"><?php echo $jobdescerr; ?></span>
                
                </div>
              </div>

              <div class="row">
                <input type="submit" name="submit" value="Submit">
              </div>
              </form>
            </div>
      </div>
      <div class="column side">

        </div>
  </div>