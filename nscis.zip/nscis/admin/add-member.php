
<?php
    error_reporting(E_ALL | E_WARNING | E_NOTICE);
    ini_set('display_errors', TRUE);
    include_once('../include/config.php');
    $title = 'add member';

    $idmember = $firstname = $lastname = $fullname = $position = $email = $DoB = $gender = $nphone = $bio = $password = $address = $religion = $file_gambar = $status= '';
    $idmembererr = $firstnameerr = $lastnameerr = $fullnameerr = $positionerr = $emailerr = $DoBerr = $gendererr = $DoBerr = $nphoneerr = $religionerr = $bioerr = $addresserr = $file_gambarerr = $statuserr ='';
    
    if (isset($_POST['submit'])) {

      //id member
      if (empty(trim($_POST['idmember']))) {
        $idmembererr = "please fill in the member";
      }else {
        $idmember = trim($_POST['idmember']);
      }

      //tanggal
      
      // first name
      if (empty(trim($_POST['firstname']))) {
        $firstnameerr = "please fill in the firstname";
      }else {
        $firstname = trim($_POST['firstname']);
      }

      // lastname
      if (empty(trim($_POST['lastname']))) {
        $lastnameerr = "please fill in the lastname";
      }else {
        $lastname = trim($_POST['lastname']);
      }

      //position
      if (empty(trim($_POST['position']))) {
        $positionerr = "please fill in the position";
      }else {
        $position = trim($_POST['position']);
      }

      // fullname
      if (empty(trim($_POST['fullname']))) {
        $fullnameerr = "please fill in the fullname";
      }else {
        $fullname = trim($_POST['fullname']);
      }

      // status
      if (empty(trim($_POST['status']))) {
        $statuserr = "please fill in the status";
      }else {
        $status= trim($_POST['status']);
      }

      // validate email
      if(empty(trim($_POST['email']))){
        $emailerr = "please fill in the email";   
      }elseif (!filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL)) {
        $emailerr = "not valid";
      } else{
        $vemail = trim($_POST['email']);
        $dataemail = mysqli_query($mysqli, "SELECT * FROM member WHERE email = '{$vemail}'");
        $check = mysqli_num_rows($dataemail);

        if ($check == 1) {
          $emailerr = "This email is already taken";
        }else{
          $email = trim($_POST['email']);
        }
      }

      // // place of birth
      // if (empty(trim($_POST['place_birth']))) {
      //   $place_birtherr = "please fill in the place of birth";
      // }else {
      //   $place_birth = trim($_POST['place_birth']);
      // }

      //DoB
      $date = trim($_POST['DoB']);
  
      // function change format date 'd/m/Y'
      function changeTanggal($date){
        $break = explode('/',$date);
        $array = array($break[2],$break[0],$break[1]);
        $unite = implode('-',$array);
        return $unite;
      }
      
      // validate tanggal
      if (empty(trim($date))) {
        $DoBerr = "please fill in the DoB"; 
      }else{
        $DoB = changeTanggal($date);
      }

      //gender
      if (empty(trim($_POST['gender']))) {
        $gendererr = "please fill in the gender";
      }else {
        $gender = trim($_POST['gender']);
      }

      //number phone
      if (empty(trim($_POST['nphone']))) {
        $nphoneerr = "please fill in the number phone";
      }elseif (!filter_var(trim($_POST['nphone']), FILTER_SANITIZE_NUMBER_INT)) {
        $nphoneerr = "please fill in using numbers";
      }elseif(strlen(trim($_POST['nphone'])) < 10 || strlen(trim($_POST['nphone'])) > 14){
        $nphoneerr = "Tel number in the range of 11 numbers or 13 numbers";
      }else{
        $nphone = trim($_POST['nphone']);
      }

      //bio
      if (empty(trim($_POST['bio']))) {
        $bioerr = "please fill in the bio";
      }else {
        $bio = trim($_POST['bio']);
      }

      //password
      $password = trim($_POST['idmember']);
      $hash = password_hash($password, PASSWORD_DEFAULT);


      //address
      if (empty(trim($_POST['address']))) {
        $addresserr = "please fill in the address";
      }else {
        $address = trim($_POST['address']);
      }

      //religion
      
      if (empty(trim($_POST['religion']))) {
        $religionerr = "please fill in the address";
      }else {
        $religion = trim($_POST['religion']);
      }

      //create
     
     

      //gambar
      $tmp_file = $_FILES["file_gambar"]["tmp_name"];
      $nm_file = $_FILES["file_gambar"]["name"];
      $ukuran_file = $_FILES["file_gambar"]["size"];
      $dir = "../image/$nm_file";
      move_uploaded_file($tmp_file, $dir);
    
      $size = 1044070; 
    
      if($ukuran_file > $size){
        $file_gambarerr = 'Ukuran Maksimal 100mb, saat ini ukuran file '.$ukuran_file;
        exit();
      }  

        //insert to table
        if (!empty($idmember) && !empty($firstname) && !empty($lastname) && !empty($fullname) && !empty($email) && !empty($DoB) && !empty($gender) && !empty($nphone) && !empty($bio) && !empty($address) && !empty($status)) {
          $sql = 'INSERT INTO member (id_member, first_name, last_name, full_name, email, no_phone, bio, dob, foto, position_id, gender, religion, password, address, status) ';
          $sql .= "VALUES ('{$idmember}','{$firstname}','{$lastname}','{$fullname}','{$email}','{$nphone}','{$bio}','{$DoB}','{$nm_file}','{$position}','{$gender}','{$religion}','{$hash}','{$address}','{$status}')";
          $result = mysqli_query($mysqli, $sql);
          if (!$result) {
            die(mysqli_error($mysqli));
          }
          header('location: member.php');
        } 

    }

    include_once('../include/header-admin.php');

?>

<div class="row">
      <div class="column side">

      </div>

      <div class="column middle">
          <h2>Biodata Form</h2>
          <p>please fill in your biodata in the following form</p>
          
          
          <div class="container">
            <form action="add-member.php" method="post" enctype="multipart/form-data">

           <!-- id member -->
            <div class="row">
                <div class="col-25">
                  <label for="fname">Officer ID</label>
                </div>
                <div class="col-75">
                  <input type="text" id="fname" name="idmember" value="<?php echo $idmember; ?>" placeholder="Your id..">
                  <span class="error"><?php echo $idmembererr; ?></span>
                </div>
              </div>
            
              <!-- first name -->
              <div class="row">
                <div class="col-25">
                  <label for="fname">First Name</label>
                </div>
                <div class="col-75">
                  <input type="text" id="fname" name="firstname" value="<?php echo $firstname; ?>" placeholder="Your name..">
                  <span class="error"><?php echo $firstnameerr; ?></span>
                </div>
              </div>

              <!-- last name -->
              <div class="row">
                  <div class="col-25">
                    <label for="lname">Last Name</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="lname" name="lastname" value="<?php echo $lastname; ?>" placeholder="Your last name..">
                    <span class="error"><?php echo $lastnameerr; ?></span>
                  </div>
                </div>


              <!-- full name -->
              <div class="row">
                <div class="col-25">
                  <label for="lname">Full Name</label>
                </div>
                <div class="col-75">
                  <input type="text" id="lname" name="fullname" value="<?php echo $fullname; ?>" placeholder="Your full name..">
                  <span class="error"><?php echo $fullnameerr; ?></span>
                </div>
              </div>


              <!-- DoB -->
              <div class="row">
                  <div class="col-25">
                    <label for="DoB">Date of Birth</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="tbDate" name="DoB" value="<?php echo $DoB; ?>" placeholder="Your DoB..">
                    <span class="error"><?php echo $DoBerr; ?></span>
                  </div>
              </div>  

              <!-- address -->
              <div class="row">
                <div class="col-25">
                  <label for="address">Address</label>
                </div>
                <div class="col-75">
                  <textarea id="address" name="address" value="<?php echo $address; ?> placeholder="Write something.." style="height:200px"></textarea>
                  <span class="error"><?php echo $addresserr; ?></span>
                </div>
              </div>

              <!-- bio -->
              <div class="row">
                  <div class="col-25">
                    <label for="bio">Bio</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="bio" name="bio" value="<?php echo $bio; ?>" placeholder="Your bio..">
                    <span class="error"><?php echo $bioerr; ?></span>
                  </div>
              </div>

             <!-- No telp -->
             <div class="row">
                  <div class="col-25">
                    <label for="nphone">No Telp</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="nphone" name="nphone" value="<?php echo $nphone; ?>" placeholder="Your Phone Number..">
                    <span class="error"><?php echo $nphoneerr; ?></span>
                  </div>
              </div>

              <!-- position -->
              <div class="row">
                <div class="col-25">
                  <label for="majors">Position</label>
                </div>
                <div class="col-75">
                  <select id="position" name="position">
                  <option >---Choose Position---</option>
                    <?php
                      include_once '../include/config.php';
                      $query ='SELECT * FROM position';
                            $hasil = mysqli_query($mysqli, $query);
                              while ($qtabel = mysqli_fetch_array($hasil))
                                {
                                    echo '<option value="'.$qtabel['id_position'].'">'.$qtabel['position_name'].'</option>';               
                                } 
                        
                    ?>
                    <span class="error"><?php echo $positionerr; ?></span>
                  </select>
                </div>
              </div>


              <!-- email -->
              <div class="row">
                  <div class="col-25">
                    <label for="email">Email</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="email" name="email" value="<?php echo $email; ?>" placeholder="Your email..">
                    <span class="error"><?php echo $emailerr; ?></span>
                  </div>
              </div>


              <!-- religion -->
              <div class="row">
                  <div class="col-25">
                    <label for="religion">Religion</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="religion" name="religion" value="<?php echo $religion; ?>" placeholder="Your Religion..">
                    <span class="error"><?php echo $religionerr; ?></span>
                  </div>
              </div>


              <!-- Place of Birth
              <div class="row">
                  <div class="col-25">
                    <label for="place_birth">Place of Birth</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="email" name="place_birth" value="<?php echo $place_birth; ?>" placeholder="Your Place of Birth..">
                    <span class="error"><?php echo $place_birtherr; ?></span>
                  </div>
              </div> -->


              <!-- gender -->
              <div class="row">
                  <div class="col-25">
                    <label for="gender">Gender</label>
                  </div>
                  <div class="col-75">
                    <label><input type="radio" value="Male" id="Male" name="gender">Male</label>
                    <label><input type="radio" value="Female" id="Female"  name="gender">Female</label>
                    <span class="error"><?php echo $gendererr; ?></span>
                  </div>
              </div>
            

              <!-- status -->
              <div class="row">
                <div class="col-25">
                  <label for="majors">Status</label>
                </div>
                <div class="col-75">
                  <select id="status" name="status">
                  <option value = "Active" >Active</option>
                  <option value ="Unactive">Unactive</option>
                    <span class="error"><?php echo $statuserr; ?></span>
                  </select>
                </div>
              </div>

              <!-- photo -->
              <div class="row">
                  <div class="col-25">
                    <label for="bio">Photo</label>
                  </div>
                  <div class="col-75">
                    <input type="file" name="file_gambar" placeholder="Your photo..">
                  </div>
              </div>

              <div class="row">
                <input type="submit" name="submit" value="Submit">
              </div>
              </form>
            </div>
      </div>
      <div class="column side">

        </div>
  </div>


<?php 
    include_once('../include/footer.php');
?>