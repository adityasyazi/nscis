<?php 
include_once('../include/config.php');

// variabel id ini dibuat dengan metode GET untuk menghapus salah satu data saja
$id = $_GET['id'];
// variabel perintah sql menghapus dari tabel position di kolom id_position berdasarkan variabel
$sql = "DELETE FROM position WHERE id_position = '{$id}'";
// membuat fungsi hasil delete data
$result = mysqli_query($mysqli, $sql);
// mengarahkan ke halaman position.php
header('Location: position.php');
 ?>