<?php 
include_once('../include/config.php');

$idpetty = $_GET['id_petty'];
$sql = "DELETE FROM petty_cash WHERE id_petty = '{$idpetty}'";

$result = mysqli_query($mysqli, $sql);

header('Location: finance.php');
 ?>