<?php
    // untuk menampilkan pesan error
    error_reporting(E_ALL | E_WARNING | E_NOTICE);
    ini_set('display_errors', TRUE);
    
    // untuk memanggil koneksi database
    include_once('../include/config.php');

    // untuk memberi judul pada website
    $title = 'add position';
    $no = 1;

    // untuk menampilkan tabel position di database nscis
    $sql = 'SELECT * FROM position';
    $result = mysqli_query($mysqli, $sql);

    // untuk memanggil tampilkan header admin
    include_once('../include/header-admin.php');
?>

<div class="row">
    <!-- membuat column dengan paragraf menjorok -->
    <div class="column left">
    </div>
        <div class="col-75">
            <h2>Position Data</h2>

            <!-- untuk menghubungkan halaman add-position.php saat d tekan button add -->
            <?php
            echo '<a href="add-position.php" class="btn btn-large"> <i class="fa fa-plus" aria-hidden="true"></i> Positions</a>';
             ?>
            <p> Data of All Staff Officer Positions </p>
            <div style="overflow-x:auto;">
        
        <!-- untuk membuat tampilan table pada website -->
        <table>
        <tr>
                <th>No.</th>
                <th>Position</th>
                <th>Job Desk</th>
                <th>Action</th>
            </tr>

            <!-- menampilkan isi tabel berdasarkan database dengan memanggil variabel result -->
            <?php while($row = mysqli_fetch_array($result)): ?>
                                    <tr>

                                    <!-- menampilan isi tabel berdasarkan nama column di database -->
                                      <td><?php echo $no; ?></td>
                                      <td><?php echo $row['position_name'];?></td>
                                      <td><?php echo $row['job_desk'];?></td>
                                      <td>
                                        <!-- membuat button edit dimana menuju ke link atau halaman edit position berdasarkan variabel id dan menampilkan nya berdasarkan id_position -->
                                        <a class="btn btn-default" href="edit-position.php?id=<?php echo $row['id_position'];?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
                                        <!-- membuat button delete lalu notikasi keluar saat button delete di tekan kemudian menghapus data berdasarkan file delete variabel id dan menghapus melalui id_position -->
                                        <a class="btn btn-alert" onclick="return confirm('Are you sure you want to delete this data?');" href="delete-position.php?id=<?php echo $row['id_position'];?>"><i class="fa fa-trash" aria-hidden="true"></i> Delete</a>
                                      </td>
                                    </tr>

                                    <!-- menampilkan array -->
                                    <!-- <?php print_r ($result)?> -->
 
                                      <!-- memberikan nomor urut isi tabel  -->
                                      <?php $no++; ?>
                                    <?php endwhile; ?>
        </table>
            </div>
        </div>
</div>

<!-- memanggil tampilan footer -->
<?php
    include_once('../include/footer.php');
?>
